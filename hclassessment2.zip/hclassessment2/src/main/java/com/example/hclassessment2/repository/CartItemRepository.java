package com.example.hclassessment2.repository;

import com.example.hclassessment2.entity.CarItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartItemRepository extends JpaRepository<CarItem, Long> {
}
