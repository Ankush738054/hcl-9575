package com.example.hclassessment2.repository;

import com.example.hclassessment2.entity.CustomerOrder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerOrderRepository extends JpaRepository<CustomerOrder,Long > {
}
