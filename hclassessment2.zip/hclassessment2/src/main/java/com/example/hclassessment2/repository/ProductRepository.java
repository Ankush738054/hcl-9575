package com.example.hclassessment2.repository;

import com.example.hclassessment2.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product,Long> {
}
