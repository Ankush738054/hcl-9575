package com.example.hclassessment2.repository;

import com.example.hclassessment2.entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartRepository extends JpaRepository<Cart,Long> {
}
