package com.example.hclassessment2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class OrderItem {
    @Id
    private Long orderId;
    @ManyToOne
    private CustomerOrder customerOrder;
    @ManyToOne
    private Product product;
    private Integer quantity;
    private Double price;
}
